# utils.py
import os
import re
import bpy
from .config import MAPS

def _tokenize_filename(name):
    base = os.path.splitext(os.path.basename(name))[0].lower()
    tokens = [t for t in re.split(r"[^a-z0-9]+", base) if t]
    return base, tokens

def _matches_alias(base, tokens, alias):
    if alias in tokens:
        return True
    if len(alias) <= 3:
        return False
    return alias in base

def detect_maps(files, log_fn=None):
    out = {}
    logger = log_fn or print
    logger("[PBRTopia] Scanning textures: {0}".format(", ".join(sorted(files))))
    for f in files:
        base, tokens = _tokenize_filename(f)
        for k, aliases in MAPS.items():
            if any(_matches_alias(base, tokens, a) for a in aliases):
                # Simple heuristic: prefer matches that are closer to exact?
                # For now just take first match
                if k not in out:
                    out[k] = f
                    logger("[PBRTopia] Matched {0} -> {1}".format(k, f))
    return out

def pack_images(mat):
    """Iterate through the material nodes and pack any images found."""
    if not mat.use_nodes: return
    for node in mat.node_tree.nodes:
        if node.type == 'TEX_IMAGE' and node.image:
            try:
                if not node.image.packed_file:
                    node.image.pack()
            except Exception as e:
                print(f"Failed to pack image {node.image.name}: {e}")

def clean_name(name):
    return name.replace("_", " ").title()
