import os
import bpy
import time
import sys

# The package name will be something like 'pbrtopia'
parent_name = __package__

_last_mtime = {}

def get_all_files():
    addon_dir = os.path.dirname(__file__)
    files = []
    for root, dirs, filenames in os.walk(addon_dir):
        if "__pycache__" in root or ".git" in root:
            continue
        for f in filenames:
            if f.endswith(".py"):
                files.append(os.path.join(root, f))
    return files

def check_for_changes():
    # If we are no longer in sys.modules, stop the timer
    if parent_name not in sys.modules:
        return None

    global _last_mtime
    
    changed = False
    files = get_all_files()
    
    # If file count changed, it's a change
    if len(files) != len(_last_mtime) and _last_mtime:
        changed = True
        
    for f in files:
        try:
            mtime = os.path.getmtime(f)
        except OSError:
            continue
            
        if f not in _last_mtime:
            _last_mtime[f] = mtime
            if len(_last_mtime) > 1: # Don't trigger on first run
                 changed = True
            continue
            
        if mtime > _last_mtime[f]:
            _last_mtime[f] = mtime
            changed = True
            
    if changed:
        print(f"[{parent_name}] Changes detected, reloading...")
        # Small delay to let file writes finish
        bpy.app.timers.register(reload_addon_safe, first_interval=0.2)
        return None # Stop this timer, the reload will start a new one
        
    return 1.0 # Check every second

def reload_addon_safe():
    import sys
    import importlib
    
    try:
        # 1. Unregister
        if parent_name in sys.modules:
            main_mod = sys.modules[parent_name]
            if hasattr(main_mod, "unregister"):
                try:
                    main_mod.unregister()
                except Exception as e:
                    print(f"[{parent_name}] Error during unregister: {e}")

        # 2. Collect all submodules to reload
        to_reload = [name for name in sys.modules if name == parent_name or name.startswith(parent_name + ".")]
        
        # 3. Remove from sys.modules to force a clean re-import
        for name in sorted(to_reload, reverse=True): # Reverse to hit submodules first
            del sys.modules[name]
            
        # 4. Re-import and register
        new_mod = importlib.import_module(parent_name)
        if hasattr(new_mod, "register"):
            new_mod.register()
            
        print(f"[{parent_name}] Reloaded successfully.")
        
    except Exception as e:
        print(f"[{parent_name}] Reload failed: {e}")
        import traceback
        traceback.print_exc()
    
    return None

def register():
    global _last_mtime
    _last_mtime = {}
    for f in get_all_files():
        try:
            _last_mtime[f] = os.path.getmtime(f)
        except OSError:
            pass
        
    # Standard way to avoid multiple timers: unregister first
    unregister()
    bpy.app.timers.register(check_for_changes, persistent=True)

def unregister():
    # Since we can't easily check for the specific function object after reload,
    # we just try to remove it. Blender's timer system is a bit opaque here.
    # But check_for_changes returns None if it detections the addon is gone.
    if bpy.app.timers.is_registered(check_for_changes):
        bpy.app.timers.unregister(check_for_changes)
