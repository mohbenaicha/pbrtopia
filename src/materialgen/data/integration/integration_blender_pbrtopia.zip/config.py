# config.py

MAPS = {
    "base_color": ["albedo", "base_color", "basecolor", "diffuse", "color"],
    "normal": ["normal", "nrm", "nor"],
    "roughness": ["roughness", "rough"],
    "specular": ["specular", "spec"],
    "metallic": ["metallic", "metal"],
    "height": ["height", "displacement", "disp", "bump"],
    "ambient_occlusion": ["ao", "ambient_occlusion", "occlusion"],
    "orm": ["orm", "occlusionroughnessmetallic", "occlusion_roughness_metallic", "arm", "rma"],
    "alpha": ["alpha", "opacity", "transparent"],
    "emission": ["emission", "emissive"]
}

DEFAULT_CONFIG = {
    "material": {
        "metallicMultiplier": 0.0,
        "smoothnessMultiplier": 0.5, # Roughness = 0.5
        "ior": 1.45,
        "transparency": 0.0,
        "parallaxScale": 0.05,
        "normalStrength": 1.0,
        "aoPower": 1.0
    }
}
