# operators.py
import bpy
import os
import shutil
import tempfile
import zipfile
import traceback
from .builder import build_material, build_material_from_folder, create_preview_plane
from .assets import ensure_asset_library_path, save_material_asset

class MATZIP_OT_import(bpy.types.Operator):
    bl_idname = "matzip.import"
    bl_label = "Import Single Material ZIP"
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.zip", options={'HIDDEN'})

    def execute(self, context):
        settings = context.scene.matzip_settings
        
        # Validation
        if settings.store_in_library and not settings.asset_path:
             self.report({'ERROR'}, "Please select an Asset Library folder or disable 'Store in Library'.")
             return {'CANCELLED'}

        try:
            # 1. Build Material
            res = build_material(self.filepath)
            mat, maps, tmp_dir = res
            try:
                node_count = len(mat.node_tree.nodes)
                print("[PBRTopia] Imported material '{0}' with {1} nodes".format(mat.name, node_count))
                for node in mat.node_tree.nodes:
                    print("[PBRTopia] NODE {0} type={1}".format(node.name, node.type))
            except Exception:
                pass

            # Ensure the material is visible by assigning it to an object.
            assigned = False
            obj = context.object
            if obj and hasattr(obj.data, "materials"):
                if len(obj.data.materials) == 0:
                    obj.data.materials.append(mat)
                else:
                    obj.data.materials[0] = mat
                try:
                    obj.active_material = mat
                    obj.active_material_index = 0
                except Exception:
                    pass
                assigned = True
                print("[PBRTopia] Assigned material to active object")
            elif settings.create_preview:
                create_preview_plane(mat)
                assigned = True
                print("[PBRTopia] Created preview plane and assigned material")
            else:
                bpy.ops.mesh.primitive_plane_add(size=2)
                obj = context.active_object
                if obj and hasattr(obj.data, "materials"):
                    obj.data.materials.append(mat)
                    try:
                        obj.active_material = mat
                        obj.active_material_index = 0
                    except Exception:
                        pass
                    assigned = True
                    print("[PBRTopia] Created plane and assigned material")
            
            # 2. Store in Library
            if settings.store_in_library:
                ensure_asset_library_path(settings.asset_path)
                # Pass albedo as preview if available
                albedo = maps.get("base_color")
                save_material_asset(mat, settings.asset_path, pack=settings.pack_imgs, preview_path=albedo)
                self.report({'INFO'}, f"Saved {mat.name} to Asset Library.")
            
            # 3. Create Preview Check
            if settings.create_preview:
                create_preview_plane(mat)
            
            # Cleanup Temp (textures are packed if saved, or in memory if in scene)
            # If we didn't pack and didn't save to library, we rely on the temp dir existing?
            # Wait, if we delete temp dir, and didn't pack, the images in scene will be lost when Blender closes/reloads or immediately?
            # Blender images from disk need the file to persist.
            # If we don't pack, we must not delete temp dir? 
            # Or we should pack automatically if valid.
            # Usually importers unpack to a texture folder next to .blend if not packing.
            # For this plugin, `pack_imgs` is critical. 
            # If not packing, we should probably warn or move textures.
            # For now, I'll delete `tmp_dir` ONLY if `pack_imgs` is True.
            # If `pack_imgs` is False, and `store_in_library` is False, user has a material pointing to temp files.
            pass # We leave temp dir if not packed. OS generally cleans temp eventuallly or user manages it
                 # Better: Pack automatically if importing to scene without library.
                 
        except Exception as e:
            self.report({'ERROR'}, f"Import Failed: {str(e)}")
            traceback.print_exc()
            return {'CANCELLED'}

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class MATZIP_OT_batch_import(bpy.types.Operator):
    bl_idname = "matzip.batch_import"
    bl_label = "Batch Import ZIP (Library Only)"
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.zip", options={'HIDDEN'})

    def execute(self, context):
        settings = context.scene.matzip_settings
        
        # Force Library Storage for Batch
        if not settings.store_in_library or not settings.asset_path:
             self.report({'ERROR'}, "Batch Import requires 'Store in Asset Library' to be enabled with a valid path.")
             return {'CANCELLED'}

        ensure_asset_library_path(settings.asset_path)
        
        temp_dir = tempfile.mkdtemp()
        processed_count = 0
        
        try:
            # Unzip Batch
            with zipfile.ZipFile(self.filepath, 'r') as z:
                z.extractall(temp_dir)
            
            # Helper to process a folder
            def process_material_folder(path):
                # We skip standard preview generation in batch to prevent crashes
                # But we CAN set albedo as preview since it's a sync image assignment
                mat = None
                try:
                    res = build_material_from_folder(path)
                    mat, maps = res
                    albedo = maps.get("base_color")
                    save_material_asset(mat, settings.asset_path, pack=settings.pack_imgs, 
                                        generate_preview=False, preview_path=albedo)
                    return True
                except Exception as ex:
                    print(f"Failed to process {path}: {ex}")
                    return False
                finally:
                    # Always cleanup from Scene to keep it clean (Library only mode)
                    if mat:
                        bpy.data.materials.remove(mat, do_unlink=True)
            
            # Recursive Search for folders containing images
            for root, dirs, files in os.walk(temp_dir):
                # If current folder has images, treat it as a material
                if any(f.lower().endswith(('.png', '.jpg', '.jpeg', '.tga', '.exr', '.hdr', '.tif', '.tiff')) for f in files):
                     if process_material_folder(root):
                         processed_count += 1
            
            self.report({'INFO'}, f"Batch Processed {processed_count} materials.")

        except Exception as e:
            self.report({'ERROR'}, f"Batch Failed: {str(e)}")
            return {'CANCELLED'}
        finally:
            # Safer cleanup on Windows
            try:
                shutil.rmtree(temp_dir, ignore_errors=True)
            except:
                pass

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
