# properties.py
import bpy
import os

class MatZipSettings(bpy.types.PropertyGroup):
    create_preview: bpy.props.BoolProperty(
        name="Create Preview Plane", 
        default=True,
        description="Create a grid plane with the material applied (Single Import Only)"
    )
    store_in_library: bpy.props.BoolProperty(
        name="Store in Asset Library", 
        default=False,
        description="Save the material into a specific Asset Library folder"
    )
    asset_path: bpy.props.StringProperty(
        name="Library Folder",
        subtype='DIR_PATH',
        description="Select the folder where assets are stored",
        default=os.path.join(os.path.expanduser("~"), "Documents", "Blender", "Assets")
    )
    pack_imgs: bpy.props.BoolProperty(
        name="Pack Images",
        default=True,
        description="Pack texture images into the .blend file (Recommended for libraries)"
    )

class PBRTopiaPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    def auto_reload_update(self, context):
        from . import reloader
        if self.auto_reload:
            reloader.register()
        else:
            reloader.unregister()

    auto_reload: bpy.props.BoolProperty(
        name="Auto Reload on Save",
        description="Automatically reload the addon when a .py file is modified (Useful for development)",
        default=False,
        update=auto_reload_update
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "auto_reload")
