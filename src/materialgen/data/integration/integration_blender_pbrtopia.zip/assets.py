# assets.py
import bpy
import os
from .utils import pack_images

def ensure_asset_library_path(path):
    path = os.path.abspath(path)
    libs = bpy.context.preferences.filepaths.asset_libraries
    for lib in libs:
        if os.path.abspath(lib.path) == path:
            return
            
    # Not found, create it
    lib_name = "UserAssets_" + os.path.basename(path)
    # Ensure unique name
    existing_names = [l.name for l in libs]
    if lib_name in existing_names:
        i = 1
        while f"{lib_name}_{i}" in existing_names:
            i += 1
        lib_name = f"{lib_name}_{i}"
        
    lib = libs.new(name=lib_name)
    lib.path = path

def save_material_asset(mat, dest_dir, pack=True, generate_preview=True, preview_path=None):
    """Saves the material to a blend file in the library."""
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)
    
    # Sanitize filename
    keep = (" ", ".", "_", "-")
    safe_name = "".join(c for c in mat.name if c.isalnum() or c in keep).rstrip()
    file_name = f"{safe_name}.blend"
    filepath = os.path.join(dest_dir, file_name)
    
    # 1. Pack Images to ensure they persist after temp dir deletion
    if pack:
        pack_images(mat)
    
    # 2. Mark Asset
    mat.asset_mark()
    
    # 3. Generate Preview
    # If albedo preview_path is provided, use it directly (Immediate/Sync)
    if preview_path and os.path.exists(preview_path):
        try:
            if bpy.app.background or not bpy.context.window_manager:
                raise RuntimeError("No UI context for custom preview")
            # Blender 4.x: use operator to set custom preview with context override
            with bpy.context.temp_override(id=mat):
                bpy.ops.ed.lib_id_load_custom_preview(filepath=preview_path)
        except Exception as e:
            print(f"Failed to set custom preview: {e}")
            # Avoid freezing on preview generation when context is invalid.
            if generate_preview and not bpy.app.background:
                try:
                    mat.preview_render_type = 'SPHERE'
                    mat.asset_generate_preview()
                except Exception as preview_err:
                    print(f"Failed to generate preview: {preview_err}")
    # Otherwise fallback to standard render (Async - can be slow/crashy in batch)
    elif generate_preview:
        if not bpy.app.background:
            try:
                mat.preview_render_type = 'SPHERE' 
                mat.asset_generate_preview()
            except Exception as preview_err:
                print(f"Failed to generate preview: {preview_err}")

    # 4. Write to Library File
    bpy.data.libraries.write(filepath, {mat}, fake_user=True)
    
    return filepath
