import bpy
import os
import tempfile
import zipfile
import json
import shutil
from .config import MAPS
from .utils import detect_maps

def build_material_from_folder(folder_path, mat_name=None, log_fn=None):
    if log_fn is None:
        log_fn = print
    if not mat_name:
        mat_name = os.path.basename(folder_path)
    
    files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tga', '.exr', '.hdr', '.tif', '.tiff'))]
    
    # 1. Load Config (Prioritizing config.json as requested)
    config = {}
    cfg_path = os.path.join(folder_path, "config.json")
    
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, 'r') as f:
                full_cfg = json.load(f)
                # Flatten the structure: merge global + material, preferring material
                if "global" in full_cfg: config.update(full_cfg["global"])
                if "material" in full_cfg: config.update(full_cfg["material"])
        except Exception as e:
            print(f"Config load error: {e}")
    # Fallback to old material.json
    elif os.path.exists(os.path.join(folder_path, "material.json")):
         try:
            with open(os.path.join(folder_path, "material.json"), "r") as f:
                config = json.load(f).get("material", {})
         except:
            pass

    # Detect and convert to absolute paths
    maps = detect_maps(files, log_fn=log_fn)
    for k in maps:
        maps[k] = os.path.join(folder_path, maps[k])

    mat = bpy.data.materials.new(mat_name)
    mat.use_nodes = True
    mat["pbr_config"] = config
    mat.cycles.displacement_method = 'BOTH'

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    # --- RESTORED STABLE NODE SETUP ---

    # Output
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (800, 0)
    out.is_active_output = True

    # BSDF
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (400, 100)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

    # Mapping
    tex_coord = nodes.new("ShaderNodeTexCoord")
    tex_coord.location = (-1200, 0)
    mapping = nodes.new("ShaderNodeMapping")
    mapping.location = (-1000, 0)
    links.new(tex_coord.outputs["UV"], mapping.inputs["Vector"])

    y_pos = 400
    def tex(path, noncolor=False):
        nonlocal y_pos
        n = nodes.new("ShaderNodeTexImage")
        try:
            img = bpy.data.images.load(path, check_existing=True)
            img.colorspace_settings.name = "Non-Color" if noncolor else "sRGB"
            n.image = img
        except:
            print(f"Failed to load {path}")
        n.location = (-700, y_pos)
        y_pos -= 300
        links.new(mapping.outputs["Vector"], n.inputs["Vector"])
        return n

    orm_outputs = None
    if "orm" in maps:
        if log_fn:
            log_fn("[PBRTopia] Using ORM map: {0}".format(maps["orm"]))
        orm_tex = tex(maps["orm"], True)
        try:
            sep = nodes.new("ShaderNodeSeparateColor")
            links.new(orm_tex.outputs["Color"], sep.inputs["Color"])
            orm_outputs = {
                "ao": sep.outputs["Red"],
                "roughness": sep.outputs["Green"],
                "metallic": sep.outputs["Blue"],
            }
            if log_fn:
                log_fn("[PBRTopia] Created Separate Color node for ORM")
        except Exception:
            sep = nodes.new("ShaderNodeSeparateRGB")
            links.new(orm_tex.outputs["Color"], sep.inputs["Image"])
            orm_outputs = {
                "ao": sep.outputs["R"],
                "roughness": sep.outputs["G"],
                "metallic": sep.outputs["B"],
            }
            if log_fn:
                log_fn("[PBRTopia] Created Separate RGB node for ORM")

    # Connect Standard Maps
    
    # 1. Base Color
    if "base_color" in maps: 
        bc_node = tex(maps["base_color"], False)
        if log_fn:
            log_fn("[PBRTopia] Connected Base Color")
        
        # AO Blending Logic (Blender 4.0+ Compatible)
        if "ambient_occlusion" in maps:
            ao_node = tex(maps["ambient_occlusion"], True)
            
            if hasattr(bpy.types, "ShaderNodeMix"):
                mix = nodes.new("ShaderNodeMix")
                mix.data_type = 'RGBA'
                mix.blend_type = 'MULTIPLY'
                mix.inputs[0].default_value = float(config.get("aoPower", 1.0))
                links.new(bc_node.outputs["Color"], mix.inputs[6])
                links.new(ao_node.outputs["Color"], mix.inputs[7])
                links.new(mix.outputs[2], bsdf.inputs["Base Color"])
            else:
                mix = nodes.new("ShaderNodeMixRGB")
                mix.blend_type = 'MULTIPLY'
                mix.inputs["Fac"].default_value = float(config.get("aoPower", 1.0))
                links.new(bc_node.outputs["Color"], mix.inputs["Color1"])
                links.new(ao_node.outputs["Color"], mix.inputs["Color2"])
                links.new(mix.outputs["Color"], bsdf.inputs["Base Color"])
            mix.location = (-400, 400)
        elif orm_outputs and orm_outputs.get("ao"):
            if log_fn:
                log_fn("[PBRTopia] AO from ORM (R channel)")
            if hasattr(bpy.types, "ShaderNodeMix"):
                mix = nodes.new("ShaderNodeMix")
                mix.data_type = 'RGBA'
                mix.blend_type = 'MULTIPLY'
                mix.inputs[0].default_value = float(config.get("aoPower", 1.0))
                links.new(bc_node.outputs["Color"], mix.inputs[6])
                links.new(orm_outputs["ao"], mix.inputs[7])
                links.new(mix.outputs[2], bsdf.inputs["Base Color"])
            else:
                mix = nodes.new("ShaderNodeMixRGB")
                mix.blend_type = 'MULTIPLY'
                mix.inputs["Fac"].default_value = float(config.get("aoPower", 1.0))
                links.new(bc_node.outputs["Color"], mix.inputs["Color1"])
                links.new(orm_outputs["ao"], mix.inputs["Color2"])
                links.new(mix.outputs["Color"], bsdf.inputs["Base Color"])
            mix.location = (-400, 400)
        else:
            links.new(bc_node.outputs["Color"], bsdf.inputs["Base Color"])
    
    # 2. Roughness
    if "roughness" in maps: 
        links.new(tex(maps["roughness"], True).outputs["Color"], bsdf.inputs["Roughness"])
        if log_fn:
            log_fn("[PBRTopia] Connected Roughness")
    elif orm_outputs and orm_outputs.get("roughness"):
        if log_fn:
            log_fn("[PBRTopia] Roughness from ORM (G channel)")
        links.new(orm_outputs["roughness"], bsdf.inputs["Roughness"])
    else:
        # Map config values to defaults
        if "smoothnessMultiplier" in config:
            # Smoothness = 1 - Roughness
            val = float(config["smoothnessMultiplier"])
            bsdf.inputs["Roughness"].default_value = 1.0 - val
        elif "roughness" in config:
            bsdf.inputs["Roughness"].default_value = float(config["roughness"])
        else:
            bsdf.inputs["Roughness"].default_value = 0.5

    # 3. Metallic
    if "metallic" in maps: 
        links.new(tex(maps["metallic"], True).outputs["Color"], bsdf.inputs["Metallic"])
        if log_fn:
            log_fn("[PBRTopia] Connected Metallic")
    elif orm_outputs and orm_outputs.get("metallic"):
        if log_fn:
            log_fn("[PBRTopia] Metallic from ORM (B channel)")
        links.new(orm_outputs["metallic"], bsdf.inputs["Metallic"])
    else:
        if "metallicMultiplier" in config:
            bsdf.inputs["Metallic"].default_value = float(config["metallicMultiplier"])
        else:
            bsdf.inputs["Metallic"].default_value = 0.0

    # 4. IOR / Transparency
    if "ior" in config:
        # Ensure it's at least 1.05 for reflections
        bsdf.inputs["IOR"].default_value = max(1.05, float(config["ior"]))
    else:
        # Default to 1.45 to ensure reflections on non-metallics
        bsdf.inputs["IOR"].default_value = 1.45
    
    if "transparency" in config:
        t_socket = "Transmission Weight" if bpy.app.version >= (4, 0, 0) else "Transmission"
        if t_socket in bsdf.inputs:
            bsdf.inputs[t_socket].default_value = float(config["transparency"])

    # 5. Emission Map
    if "emission" in maps:
        em_node = tex(maps["emission"], False)
        e_socket = "Emission Color" if bpy.app.version >= (4, 0, 0) else "Emission"
        if e_socket in bsdf.inputs:
            links.new(em_node.outputs["Color"], bsdf.inputs[e_socket])

    # 6. Height / Bump / Displacement
    # bump = None  # [DEPRECATED] Removed to prevent pixelated height map artifacts in normals
    if "height" in maps:
        ht_node = tex(maps["height"], True)
        if log_fn:
            log_fn("[PBRTopia] Connected Height/Displacement")
        
        # Use parallaxScale for displacement strength, default 0.05
        p_scale = float(config.get("parallaxScale", 0.05))
        
        # [DEPRECATED] Bump Node logic removed as it creates jagged artifacts when combined with Normal maps
        # bump = nodes.new("ShaderNodeBump")
        # bump.location = (0, -200)
        # bump.inputs["Distance"].default_value = p_scale
        # links.new(ht_node.outputs["Color"], bump.inputs["Height"])

        # Displacement Node (Connected directly to Material Output)
        disp = nodes.new("ShaderNodeDisplacement")
        disp.location = (400, -300)
        disp.inputs["Scale"].default_value = p_scale
        disp.inputs["Midlevel"].default_value = 0.0 
        
        links.new(ht_node.outputs["Color"], disp.inputs["Height"])
        links.new(disp.outputs["Displacement"], out.inputs["Displacement"])

    # 7. Normal Map
    if "normal" in maps:
        nt_node = tex(maps["normal"], True)
        if log_fn:
            log_fn("[PBRTopia] Connected Normal")
        nrm_map = nodes.new("ShaderNodeNormalMap")
        nrm_map.location = (-300, -200)
        nrm_map.inputs["Strength"].default_value = float(config.get("normalStrength", 1.0))
        links.new(nt_node.outputs["Color"], nrm_map.inputs["Color"])

        # Connect Normal Map directly to BSDF (No Bump bridging)
        links.new(nrm_map.outputs["Normal"], bsdf.inputs["Normal"])
    
    return mat, maps

def build_material(zip_path=None, log_fn=None):
    if log_fn is None:
        log_fn = print
    """
    Wrapper to handle ZIP extraction.
    """
    tmp = tempfile.mkdtemp()
    try:
        with zipfile.ZipFile(zip_path, 'r') as z: 
            z.extractall(tmp)
        
        # Handle cases where zip contains a single folder wrapper
        entries = os.listdir(tmp)
        images = [f for f in entries if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tga'))]
        root = tmp
        if not images and len(entries) == 1 and os.path.isdir(os.path.join(tmp, entries[0])):
             root = os.path.join(tmp, entries[0])
        
        res = build_material_from_folder(root, os.path.splitext(os.path.basename(zip_path))[0], log_fn=log_fn)
        mat, maps = res
        return mat, maps, tmp
    except Exception as e:
        shutil.rmtree(tmp)
        raise e

def create_preview_plane(mat):
    # Switch to Cycles
    bpy.context.scene.render.engine = 'CYCLES'
    try:
        bpy.context.scene.cycles.feature_set = 'EXPERIMENTAL'
    except:
        pass

    bpy.ops.object.select_all(action='DESELECT')
    
    # Grid Primitive
    bpy.ops.mesh.primitive_grid_add(x_subdivisions=100, y_subdivisions=100, size=2)
    obj = bpy.context.active_object
    obj.name = f"Preview_{mat.name}"
    
    bpy.ops.object.shade_smooth()
    obj.data.materials.append(mat)
    
    # Setup Displace Modifier for VIEWPORT visibility
    disp_image = None
    nodes = mat.node_tree.nodes
    
    for node in nodes:
        if node.type == 'DISPLACEMENT' and node.inputs['Height'].is_linked:
            try:
                link = node.inputs['Height'].links[0]
                if link.from_node.type == 'TEX_IMAGE':
                    disp_image = link.from_node.image
                    break
            except:
                pass
    
    if disp_image:
        tex_name = f"Preview_Disp_{mat.name}"
        tex = bpy.data.textures.get(tex_name)
        if not tex:
            tex = bpy.data.textures.new(name=tex_name, type='IMAGE')
        tex.image = disp_image
        
        mod = obj.modifiers.new("Preview_Displacement", 'DISPLACE')
        mod.texture = tex
        mod.texture_coords = 'UV'
        mod.mid_level = 0.0 
        
        config = mat.get("pbr_config", {})
        mod.strength = float(config.get("parallaxScale", 0.05))
        
    # UX: Switch Viewport
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            area.spaces[0].shading.type = 'MATERIAL' 
            
            # Use temp_override for modern Blender versions
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if region:
                try:
                    with bpy.context.temp_override(area=area, region=region):
                        bpy.ops.view3d.view_selected()
                except:
                    pass

    return obj


