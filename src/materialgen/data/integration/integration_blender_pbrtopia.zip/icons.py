# icons.py
import bpy
import os
import bpy.utils.previews

preview_collections = {}

def register_icons():
    pcoll = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    
    # Load logo if exists
    logo_path = os.path.join(icons_dir, "PBRTopiaLogo.png")
    if os.path.exists(logo_path):
        pcoll.load("logo", logo_path, 'IMAGE')
    
    preview_collections["main"] = pcoll

def unregister_icons():
    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()

def get_logo_icon_id():
    pcoll = preview_collections.get("main")
    if pcoll and "logo" in pcoll:
        return pcoll["logo"].icon_id
    return 0
