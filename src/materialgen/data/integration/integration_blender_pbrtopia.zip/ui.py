# ui.py
import bpy

from .icons import get_logo_icon_id

class MATZIP_PT_panel(bpy.types.Panel):
    bl_label = "PBRTopia Material Importer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'PBRTopia' 
    
    def draw(self, context):
        layout = self.layout
        settings = context.scene.matzip_settings
        
        # Logo
        icon_id = get_logo_icon_id()
        if icon_id:
             row = layout.row()
             row.alignment = 'CENTER'
             row.template_icon(icon_value=icon_id, scale=5.0)
             # Layout Spacer
             layout.separator(factor=1.0)
        
        box = layout.box()
        box.label(text="Settings", icon='PREFERENCES')
        box.prop(settings, "create_preview")
        box.prop(settings, "store_in_library")
        if settings.store_in_library:
            box.prop(settings, "asset_path")
            box.prop(settings, "pack_imgs")
        
        layout.separator()
        
        col = layout.column(align=True)
        col.operator("matzip.import", text="Import Single Material", icon='IMPORT')
        
        sub = col.row()
        sub.enabled = settings.store_in_library
        sub.operator("matzip.batch_import", text="Batch Import (Library)", icon='FILE_ARCHIVE')
        if not settings.store_in_library:
            col.label(text="Enable 'Store in Library' for Batch", icon='INFO')

        layout.separator(factor=2.0)
        row = layout.row()
        row.alignment = 'CENTER'
        op = row.operator("wm.url_open", text="Terms & Conditions", icon='URL')
        op.url = "https://pbrtopia.com/terms"
