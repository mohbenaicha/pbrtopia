# __init__.py
bl_info = {
    "name": "PBRTopia Material Importer",
    "author": "PBRTopia by Wonder Art Technologies",
    "version": (1, 0, 0),
    "blender": (3, 6, 0),
    "location": "View3D > UI > PBRTopia",
    "description": "Import PBR materials from ZIP (Single or Batch) with Asset Browser support.",
    "warning": "",
    "doc_url": "https://pbrtopia.com/",
    "category": "Material",
}

import bpy
from .properties import MatZipSettings, PBRTopiaPreferences
from .operators import MATZIP_OT_import, MATZIP_OT_batch_import
from .ui import MATZIP_PT_panel
from .icons import register_icons, unregister_icons
from . import reloader

classes = (
    MatZipSettings,
    PBRTopiaPreferences,
    MATZIP_OT_import,
    MATZIP_OT_batch_import,
    MATZIP_PT_panel,
)

def register():
    register_icons()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.matzip_settings = bpy.props.PointerProperty(type=MatZipSettings)
    
    # Check if auto reload should be active
    try:
        addon_prefs = bpy.context.preferences.addons.get(__package__)
        if addon_prefs and addon_prefs.preferences.auto_reload:
            reloader.register()
    except Exception as e:
        print(f"[{__package__}] Could not initialize reloader: {e}")

def unregister():
    reloader.unregister()
    del bpy.types.Scene.matzip_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    unregister_icons()

if __name__ == "__main__":
    register()
