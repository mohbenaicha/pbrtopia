+ PBRTopia 1.0.0 PBRTopia_Distribution
scripts: scripts
icons: icons
PYTHONPATH +:= python
