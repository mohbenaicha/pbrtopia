"""
UI for Pbrtopia Maya Material Importer.
"""

import os
import shutil
import traceback
import zipfile

import maya.cmds as cmds
import maya.mel as mel

from .config import (
    PLUGIN_NAME,
    VERSION,
    WINDOW_NAME,
    PROJECT_WEBSITE,
    TERMS_URL,
    SUPPORT_URL,
    LOGO_FILENAME,
)
from .utils import (
    _normalize_path,
    _default_materials_folder,
    _warn,
    _script_dir,
)
from .materials import (
    import_pbr_material,
    batch_import_materials,
    _extract_zip_to_temp,
    _discover_material_folders,
)


def _ui_set_text(ctrl, text):
    if cmds.control(ctrl, q=True, exists=True):
        cmds.textField(ctrl, e=True, text=text)


def _ui_get_text(ctrl):
    if cmds.control(ctrl, q=True, exists=True):
        return cmds.textField(ctrl, q=True, text=True)
    return ""


def _ui_log(ctrl, msg):
    if cmds.control(ctrl, q=True, exists=True):
        old = cmds.scrollField(ctrl, q=True, text=True)
        cmds.scrollField(ctrl, e=True, text=old + "\n" + msg)


def _ui_get_option(ctrl):
    if cmds.control(ctrl, q=True, exists=True):
        return cmds.optionMenu(ctrl, q=True, value=True)
    return ""


def _browse_folder(field):
    path = cmds.fileDialog2(dialogStyle=2, fileMode=3)
    if path:
        _ui_set_text(field, path[0])


def _browse_file(field, caption="Select File"):
    path = cmds.fileDialog2(dialogStyle=2, fileMode=1, caption=caption)
    if path:
        _ui_set_text(field, path[0])


def _open_folder(path):
    path = _normalize_path(path)
    if not os.path.exists(path):
        _warn("Folder not found: {0}".format(path))
        return
    try:
        os.startfile(path)
    except Exception:
        try:
            import subprocess
            subprocess.Popen(["open", path])
        except Exception:
            _warn("Unable to open folder: {0}".format(path))


def _refresh_library_list(list_ctrl, folder):
    if not cmds.control(list_ctrl, q=True, exists=True):
        return
    cmds.textScrollList(list_ctrl, e=True, removeAll=True)
    folder = _normalize_path(folder)
    if not os.path.exists(folder):
        return
    for entry in sorted(os.listdir(folder)):
        if entry.lower().endswith(".ma"):
            cmds.textScrollList(list_ctrl, e=True, append=entry)


def _import_selected_material(list_ctrl, folder):
    items = cmds.textScrollList(list_ctrl, q=True, selectItem=True) or []
    if not items:
        _warn("No material selected.")
        return
    path = os.path.join(folder, items[0])
    if not os.path.exists(path):
        _warn("Material file not found: {0}".format(path))
        return
    cmds.file(path, i=True, type="mayaAscii", ignoreVersion=True, mergeNamespacesOnClash=True, namespace=":")


def _remove_selected_materials(list_ctrl, folder):
    items = cmds.textScrollList(list_ctrl, q=True, selectItem=True) or []
    if not items:
        _warn("No materials selected.")
        return
    confirm = cmds.confirmDialog(
        title="Remove Materials",
        message="Remove {0} material file(s) from the library?".format(len(items)),
        button=["Remove", "Cancel"],
        defaultButton="Remove",
        cancelButton="Cancel",
        dismissString="Cancel",
    )
    if confirm != "Remove":
        return
    for item in items:
        path = os.path.join(folder, item)
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception as exc:
                _warn("Failed to remove: {0} ({1})".format(path, exc))


def _run_batch_import(save_field, preview_chk, skydome_chk, hdri_field, render_menu, log_field, list_ctrl):
    # `Preview_chk` and `skydome_chk` are ignored in batch mode since they apply per-material. Batch import will create previews/skydomes if enabled for each material.
    save_folder = _normalize_path(_ui_get_text(save_field))
    hdri_path = _normalize_path(_ui_get_text(hdri_field))
    render_mode = _ui_get_option(render_menu).lower()

    res = cmds.confirmDialog(
        title="Batch Import",
        message="Select source type to scan for materials:",
        button=["Folder", "Zip File", "Cancel"],
        defaultButton="Folder",
        cancelButton="Cancel",
        dismissString="Cancel",
    )
    source = None
    if res == "Folder":
        path = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Source Folder")
        if path:
            source = path[0]
    elif res == "Zip File":
        path = cmds.fileDialog2(dialogStyle=2, fileMode=1, caption="Select Source Zip")
        if path:
            source = path[0]

    if not source:
        return

    if not save_folder:
        save_folder = _default_materials_folder()
        _ui_set_text(save_field, save_folder)

    _ui_log(log_field, "Batch import started: {0}".format(source))

    try:
        imported = batch_import_materials(
            source,
            save_folder=save_folder,
            create_preview=False,
            create_skydome=False,
            hdri_path=hdri_path,
            render_mode=render_mode,
            log_fn=lambda m: _ui_log(log_field, m),
        )
        exported_count = len([m for m in imported if m and m.get("exported")])
        _ui_log(log_field, "Batch import complete. Imported: {0}".format(exported_count))
        _refresh_library_list(list_ctrl, save_folder)
    except Exception:
        _ui_log(log_field, "Error: {0}".format(traceback.format_exc()))


def _run_single_import(save_field, preview_chk, skydome_chk, hdri_field, render_menu, log_field, list_ctrl):
    save_folder = _normalize_path(_ui_get_text(save_field))
    create_preview = cmds.checkBox(preview_chk, q=True, value=True)
    create_skydome = cmds.checkBox(skydome_chk, q=True, value=True)
    hdri_path = _normalize_path(_ui_get_text(hdri_field))
    render_mode = _ui_get_option(render_menu).lower()

    res = cmds.confirmDialog(
        title="Import Single Material",
        message="Select material source type:",
        button=["Folder", "Zip File", "Cancel"],
        defaultButton="Folder",
        cancelButton="Cancel",
        dismissString="Cancel",
    )
    source = None
    if res == "Folder":
        path = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Material Folder")
        if path:
            source = path[0]
    elif res == "Zip File":
        path = cmds.fileDialog2(dialogStyle=2, fileMode=1, caption="Select Material Zip")
        if path:
            source = path[0]

    if not source:
        return

    if not save_folder:
        save_folder = _default_materials_folder()
        _ui_set_text(save_field, save_folder)

    _ui_log(log_field, "Single import started: {0}".format(source))

    try:
        if zipfile.is_zipfile(source):
            tmp = _extract_zip_to_temp(source)
            try:
                folders = _discover_material_folders(tmp)
                if len(folders) > 1:
                    cmds.confirmDialog(
                        title="Multiple Materials Found",
                        message="This zip contains {0} materials. Please use 'Batch Import' instead.".format(len(folders)),
                        button=["OK"],
                    )
                    _ui_log(log_field, "Aborted: Multiple materials found in zip.")
                    return
                if not folders:
                    _warn("No textures found in zip.")
                    _ui_log(log_field, "Failed: No textures found in zip.")
                    return
                result = import_pbr_material(
                    folders[0],
                    save_folder=save_folder,
                    create_preview=create_preview,
                    create_skydome=create_skydome,
                    hdri_path=hdri_path,
                    render_mode=render_mode,
                    log_fn=lambda m: _ui_log(log_field, m),
                )
            finally:
                shutil.rmtree(tmp)
        else:
            result = import_pbr_material(
                source,
                save_folder=save_folder,
                create_preview=create_preview,
                create_skydome=create_skydome,
                hdri_path=hdri_path,
                render_mode=render_mode,
                log_fn=lambda m: _ui_log(log_field, m),
            )

        _ui_log(log_field, "Import: {0}".format("OK" if result and result.get("exported") else "FAILED"))
        _refresh_library_list(list_ctrl, save_folder)
    except Exception:
        _ui_log(log_field, "Error: {0}".format(traceback.format_exc()))


def _build_ui():
    if cmds.window(WINDOW_NAME, exists=True):
        cmds.deleteUI(WINDOW_NAME)

    window = cmds.window(WINDOW_NAME, title=PLUGIN_NAME, widthHeight=(560, 520))
    cmds.columnLayout(adjustableColumn=True)

    logo_path = os.path.join(_script_dir(), LOGO_FILENAME)
    if os.path.exists(logo_path):
        cmds.image(image=logo_path)
    else:
        cmds.text(label=PLUGIN_NAME, font="boldLabelFont")
    cmds.separator(height=6, style="in")

    tabs = cmds.tabLayout(innerMarginWidth=8, innerMarginHeight=8)

    import_tab = cmds.columnLayout(adjustableColumn=True)

    cmds.frameLayout(label="Instructions", collapsable=True, collapse=True, marginWidth=5, marginHeight=5)
    cmds.columnLayout(adjustableColumn=True)
    cmds.text(label="To import your downloaded PBRTopia materials:", align="left")
    cmds.text(label="1. Select your Maya library folder where the materials will be stored.", align="left")
    cmds.text(label="2. Select a material renderer and optional HDRI.", align="left")
    cmds.text(label="3. For single materials, toggle preview plane/skydome settings.", align="left")
    cmds.text(label="4. Click Batch Import or Import Single Material to select and import.", align="left")
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.separator(height=10, style="single")

    cmds.text(label="Select a folder for saving imported materials (one .ma per material):")
    save_field = cmds.textField(text=_default_materials_folder())
    cmds.rowLayout(numberOfColumns=2, columnAlign2=("left", "left"), adjustableColumn=1)
    cmds.button(label="Browse Library Folder", command=lambda *_: _browse_folder(save_field))
    cmds.button(label="Open Library Folder", command=lambda *_: _open_folder(_ui_get_text(save_field)))
    cmds.setParent("..")

    cmds.separator(height=6, style="in")

    cmds.text(label="Material Mode")
    render_menu = cmds.optionMenu()
    cmds.menuItem(label="Arnold")
    cmds.menuItem(label="Standard")

    cmds.text(label="HDRI (optional)")
    hdri_field = cmds.textField()
    cmds.rowLayout(numberOfColumns=2, columnAlign2=("left", "left"), adjustableColumn=1)
    cmds.button(label="Browse HDRI", command=lambda *_: _browse_file(hdri_field, caption="Select HDRI"))
    cmds.button(label="Clear HDRI", command=lambda *_: _ui_set_text(hdri_field, ""))
    cmds.setParent("..")

    cmds.separator(height=8, style="in")

    cmds.text(label="Single Import Settings:")
    preview_chk = cmds.checkBox(label="Create preview planes", value=True)
    skydome_chk = cmds.checkBox(label="Create Arnold Skydome Light", value=True)

    cmds.separator(height=8, style="in")

    cmds.rowLayout(numberOfColumns=2, columnAlign2=("left", "left"), adjustableColumn=1)
    cmds.button(label="Batch Import", height=40, backgroundColor=(0.2, 0.4, 0.6),
                command=lambda *_: _run_batch_import(save_field, preview_chk, skydome_chk, hdri_field, render_menu, log_field, library_list))
    cmds.button(label="Import Single Material", height=40, backgroundColor=(0.2, 0.6, 0.4),
                command=lambda *_: _run_single_import(save_field, preview_chk, skydome_chk, hdri_field, render_menu, log_field, library_list))
    cmds.setParent("..")

    cmds.separator(height=8, style="in")
    cmds.text(label="Log")
    log_field = cmds.scrollField(height=220, editable=False, wordWrap=True, text="Ready.")

    cmds.setParent("..")

    library_tab = cmds.columnLayout(adjustableColumn=True)
    cmds.text(label="Material Library (.ma files)")
    cmds.separator(height=6, style="in")

    library_list = cmds.textScrollList(height=220, allowMultiSelection=True)
    cmds.rowLayout(numberOfColumns=4, columnAlign4=("left", "left", "left", "left"), adjustableColumn=1)
    cmds.button(label="Refresh", command=lambda *_: _refresh_library_list(library_list, _ui_get_text(save_field)))
    cmds.button(label="Import Selected", command=lambda *_: _import_selected_material(library_list, _ui_get_text(save_field)))
    cmds.button(label="Remove Selected", command=lambda *_: (_remove_selected_materials(library_list, _ui_get_text(save_field)),
                                                              _refresh_library_list(library_list, _ui_get_text(save_field))))
    cmds.button(label="Open Library Folder", command=lambda *_: _open_folder(_ui_get_text(save_field)))
    cmds.setParent("..")

    cmds.separator(height=8, style="in")
    cmds.text(label="Tip: You can view imported materials in Hypershade or drag them onto meshes.")

    cmds.setParent("..")

    about_tab = cmds.columnLayout(adjustableColumn=True)

    cmds.text(label="Version: {0}".format(VERSION))
    cmds.text(label="Copyright (c) 2025 PBRTopia. All rights reserved.")

    cmds.separator(height=6, style="in")
    cmds.text(label="Links")
    cmds.rowLayout(numberOfColumns=3, columnAlign3=("left", "left", "left"), adjustableColumn=1)
    cmds.button(label="www.pbrtopia.com", command=lambda *_: __import__("webbrowser").open(PROJECT_WEBSITE))
    cmds.button(label="Terms", command=lambda *_: __import__("webbrowser").open(TERMS_URL))
    cmds.button(label="Support", command=lambda *_: __import__("webbrowser").open(SUPPORT_URL))
    cmds.setParent("..")

    cmds.separator(height=6, style="in")

    cmds.setParent("..")

    cmds.tabLayout(tabs, e=True, tabLabel=((import_tab, "Import"), (library_tab, "Library"), (about_tab, "About")))

    _refresh_library_list(library_list, _ui_get_text(save_field))

    cmds.showWindow(window)


def show_ui():
    _build_ui()


def _main_window():
    try:
        return mel.eval("$tmp=$gMainWindow")
    except Exception:
        return None


def install_menu():
    main_window = _main_window()
    if not main_window:
        return

    menu_name = "PbrtopiaMenu"
    if cmds.menu(menu_name, exists=True):
        try:
            cmds.deleteUI(menu_name)
        except Exception:
            pass

    menu = cmds.menu(menu_name, label="PBRTopia", parent=main_window, tearOff=True)
    cmds.menuItem(label="Open Importer", parent=menu, command=lambda *_: show_ui())
    cmds.menuItem(divider=True, parent=menu)
    cmds.menuItem(label="Project Website", parent=menu, command=lambda *_: __import__("webbrowser").open(PROJECT_WEBSITE))
    cmds.menuItem(label="Support", parent=menu, command=lambda *_: __import__("webbrowser").open(SUPPORT_URL))


def install_shelf_button():
    try:
        shelf_top = mel.eval("$tmp=$gShelfTopLevel")
    except Exception:
        return

    shelf_name = "PBRTopia"
    existing = cmds.shelfTabLayout(shelf_top, q=True, tabLabel=True) or []
    if shelf_name not in existing:
        cmds.shelfLayout(shelf_name, parent=shelf_top)
    else:
        # Clear existing buttons to avoid duplicates on every restart
        buttons = cmds.shelfLayout(shelf_name, q=True, childArray=True) or []
        for btn in buttons:
            if cmds.shelfButton(btn, q=True, label=True) == "PBRTopia":
                cmds.deleteUI(btn)

    cmds.shelfButton(
        parent=shelf_name,
        label="PBRTopia",
        annotation="Open PBRTopia Importer",
        command="import pbrtopia; pbrtopia.show_ui()",
        image="PBRTopia_icon.png",
    )


def install_ui_access():
    install_menu()
    install_shelf_button()
