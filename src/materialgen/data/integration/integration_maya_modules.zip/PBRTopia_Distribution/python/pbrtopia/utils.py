"""
Utility helpers for Pbrtopia Maya Material Importer.
"""

import os
import inspect

import maya.cmds as cmds

from .config import SUPPORTED_EXTS


def _info(msg):
    print("[Pbrtopia] {0}".format(msg))


def _warn(msg):
    cmds.warning("[Pbrtopia] {0}".format(msg))


def _error(msg):
    cmds.error("[Pbrtopia] {0}".format(msg))


def _normalize_path(path):
    if not path:
        return ""
    path = os.path.expandvars(path)
    path = os.path.expanduser(path)
    return os.path.abspath(path)


def _safe_mkdir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def _project_root():
    try:
        root = cmds.workspace(q=True, rootDirectory=True)
        if root:
            return _normalize_path(root)
    except Exception:
        pass
    return _normalize_path(os.getcwd())


def _default_materials_folder():
    return os.path.join(_project_root(), "Materials")


def _script_dir():
    """Return the directory where this script lives, even when __file__ is undefined."""
    try:
        path = inspect.getsourcefile(lambda: None)
        if path:
            return os.path.dirname(os.path.abspath(path))
    except Exception:
        pass

    try:
        script_dir = cmds.internalVar(userScriptDir=True)
        if script_dir:
            return _normalize_path(script_dir)
    except Exception:
        pass

    return _project_root()


def _list_texture_files(folder_path):
    files = []
    for entry in os.listdir(folder_path):
        path = os.path.join(folder_path, entry)
        if os.path.isfile(path) and os.path.splitext(entry)[1].lower() in SUPPORTED_EXTS:
            files.append(path)
    return files


def _connect_place2d_to_file(place2d, file_node):
    attrs = [
        "coverage", "translateFrame", "rotateFrame", "mirrorU", "mirrorV",
        "stagger", "wrapU", "wrapV", "repeatUV", "offset", "rotateUV",
        "noiseUV", "vertexUvOne", "vertexUvTwo", "vertexUvThree", "vertexCameraOne",
    ]
    for attr in attrs:
        try:
            cmds.connectAttr("{0}.{1}".format(place2d, attr), "{0}.{1}".format(file_node, attr), f=True)
        except Exception:
            pass
    try:
        cmds.connectAttr("{0}.outUV".format(place2d), "{0}.uvCoord".format(file_node), f=True)
    except Exception:
        pass
    try:
        cmds.connectAttr("{0}.outUvFilterSize".format(place2d), "{0}.uvFilterSize".format(file_node), f=True)
    except Exception:
        pass


def _create_file_texture(node_name, path, non_color=None):
    file_node = cmds.shadingNode("file", asTexture=True, name=node_name)
    place2d = cmds.shadingNode("place2dTexture", asUtility=True, name="{0}_Place2d".format(node_name))
    _connect_place2d_to_file(place2d, file_node)
    cmds.setAttr("{0}.fileTextureName".format(file_node), path, type="string")
    return file_node


def _is_unknown_node(node):
    try:
        ntype = cmds.nodeType(node)
        return ntype in ("unknown", "unknownDag", "unknownTransform")
    except Exception:
        return True
