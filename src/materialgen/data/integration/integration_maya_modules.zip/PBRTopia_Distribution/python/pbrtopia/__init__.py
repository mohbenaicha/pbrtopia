"""Pbrtopia Maya Material Importer package."""

from .config import PLUGIN_NAME, VERSION
from .ui import show_ui, install_ui_access

__all__ = [
    "PLUGIN_NAME",
    "VERSION",
    "show_ui",
    "install_ui_access",
]

if __name__ == "__main__":
    show_ui()
