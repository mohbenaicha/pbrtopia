"""
Material import and export logic for Pbrtopia Maya Material Importer.
"""

import os
import re
import shutil
import tempfile
import zipfile

import maya.cmds as cmds
import maya.mel as mel

from .config import TEXTURE_KEYWORDS
from .utils import (
    _warn,
    _safe_mkdir,
    _normalize_path,
    _list_texture_files,
    _create_file_texture,
    _is_unknown_node,
)
from .arnold import _ensure_arnold_loaded, _create_skydome_light


def _tokenize_filename(name):
    base = os.path.splitext(os.path.basename(name))[0].lower()
    tokens = [t for t in re.split(r"[^a-z0-9]+", base) if t]
    return base, tokens

def _matches_keyword(base, tokens, key):
    if key in tokens:
        return True
    if len(key) <= 3:
        return False
    return key in base

def _pick_texture_by_keywords(folder_path):
    """Return a dict of attr -> texture path based on filename keywords."""
    textures = {}
    files = _list_texture_files(folder_path)
    if not files:
        return textures

    for attr, keywords in TEXTURE_KEYWORDS.items():
        best = None
        best_score = 9999
        for file_path in files:
            base, tokens = _tokenize_filename(file_path)
            for key in keywords:
                if _matches_keyword(base, tokens, key):
                    score = len(base)
                    if score < best_score:
                        best = file_path
                        best_score = score
        if best:
            textures[attr] = best

    return textures


def _create_preview_plane(mat_name, sg):
    plane = cmds.polyPlane(w=2, h=2, sx=1, sy=1, name="Preview_{0}".format(mat_name))[0]
    cmds.sets(plane, e=True, forceElement=sg)
    if not cmds.objExists("Pbrtopia_Preview_GRP"):
        cmds.group(plane, name="Pbrtopia_Preview_GRP")
    else:
        cmds.parent(plane, "Pbrtopia_Preview_GRP")
    return plane


def _refresh_swatches(nodes, log_fn=None):
    try:
        mel.eval("refreshHyperShade;")
    except Exception:
        pass
    try:
        cmds.refresh(force=True)
    except Exception:
        pass
    for node in nodes:
        try:
            cmds.swatchDisplayPort(node, edit=True, rebuild=True)
        except Exception:
            pass
    if log_fn:
        log_fn("Swatch refresh requested for {0} nodes".format(len(nodes)))


def _collect_shading_nodes(material, shading_group):
    nodes = set([material, shading_group])
    history = cmds.listHistory(material, future=False, pruneDagObjects=True) or []
    for node in history:
        nodes.add(node)
    sg_hist = cmds.listHistory(shading_group, future=False, pruneDagObjects=True) or []
    for node in sg_hist:
        nodes.add(node)
    return list(nodes)


def _filter_unknown_nodes(nodes):
    filtered = []
    for node in nodes:
        if _is_unknown_node(node):
            if node.startswith("Pbrtopia_"):
                try:
                    cmds.delete(node)
                except Exception:
                    pass
            continue
        filtered.append(node)
    return filtered


def _export_material_nodes(nodes, file_path):
    cmds.select(clear=True)
    nodes = _filter_unknown_nodes(nodes)
    if not nodes:
        return False

    cmds.select(nodes, r=True, ne=True)
    try:
        cmds.file(file_path, force=True, options="v=0;", type="mayaAscii", exportSelected=True)
        return True
    except RuntimeError as exc:
        msg = str(exc)
        if "unknown" in msg.lower() and "file format" in msg.lower():
            _warn("Export failed due to unknown nodes. Attempting aggressive cleanup...")
            unknowns = cmds.ls(type="unknown") or []
            if unknowns:
                try:
                    cmds.delete(unknowns)
                except Exception:
                    pass
            try:
                cmds.file(file_path, force=True, options="v=0;", type="mayaAscii", exportSelected=True)
                return True
            except Exception:
                _warn("Export retry also failed. Ensure Arnold (mtoa) is loaded.")
                return False
        raise


def import_pbr_material(folder_path, mat_name=None, save_folder=None, create_preview=True, create_skydome=True, hdri_path=None, render_mode="arnold", log_fn=None):
    """Import a single PBR material from a folder and optionally save to disk."""
    folder_path = _normalize_path(folder_path)
    if not os.path.exists(folder_path):
        _warn("Folder not found: {0}".format(folder_path))
        return None

    if log_fn:
        log_fn("Importing folder: {0}".format(folder_path))

    render_mode = (render_mode or "arnold").lower()
    if render_mode == "standard":
        arnold_available = False
        if log_fn:
            log_fn("Render mode set to Standard.")
    else:
        arnold_available = _ensure_arnold_loaded(log_fn=log_fn)

    if not mat_name:
        mat_name = os.path.basename(folder_path.rstrip("/\\"))

    textures = _pick_texture_by_keywords(folder_path)
    if log_fn:
        log_fn("Detected texture files: {0}".format(", ".join(sorted(os.path.basename(p) for p in _list_texture_files(folder_path)))) )
    if not textures:
        _warn("No supported textures found in: {0}".format(folder_path))
        if log_fn:
            log_fn("No supported textures found in: {0}".format(folder_path))
    elif log_fn:
        log_fn("Detected textures: {0}".format(", ".join(sorted(textures.keys()))))

    # 1. Create material and shading group
    fallback_type = "blinn"
    try:
        if not arnold_available and cmds.nodeType("standardSurface", isTypeName=True):
            fallback_type = "standardSurface"
    except Exception:
        pass

    shader_type = "aiStandardSurface" if arnold_available else fallback_type

    attr_map = {
        "baseColor": {
            "aiStandardSurface": "baseColor",
            "standardSurface": "baseColor",
            "blinn": "color",
            "lambert": "color",
        },
        "specularRoughness": {
            "aiStandardSurface": "specularRoughness",
            "standardSurface": "specularRoughness",
            "blinn": "eccentricity",
            "lambert": None,
        },
        "metalness": {
            "aiStandardSurface": "metalness",
            "standardSurface": "metalness",
            "blinn": "specularRollOff",
            "lambert": None,
        },
        "emission": {
            "aiStandardSurface": "emissionColor",
            "standardSurface": "emissionColor",
            "blinn": "incandescence",
            "lambert": "incandescence",
        },
        "normal": {
            "aiStandardSurface": "normalCamera",
            "standardSurface": "normalCamera",
            "blinn": "normalCamera",
            "lambert": "normalCamera",
        },
        "opacity": {
            "aiStandardSurface": "opacity",
            "standardSurface": "opacity",
            "blinn": "transparency",
            "lambert": "transparency",
        },
    }

    try:
        mat = cmds.shadingNode(shader_type, asShader=True, name=mat_name)
        if not arnold_available:
            _warn("Arnold not available. Using {0} as fallback.".format(shader_type))
        if log_fn:
            log_fn("Created shader node: {0} ({1})".format(mat, shader_type))
        if shader_type == "aiStandardSurface" and cmds.attributeQuery("base", node=mat, exists=True):
            cmds.setAttr("{0}.base".format(mat), 1.0)
    except Exception as exc:
        _warn("Failed to create material node: {0}".format(exc))
        if log_fn:
            log_fn("CRITICAL ERROR: Failed to create material node {0}: {1}".format(mat_name, exc))
        return None

    try:
        sg = cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name="{0}SG".format(mat_name))
        cmds.connectAttr("{0}.outColor".format(mat), "{0}.surfaceShader".format(sg), f=True)
        if log_fn:
            log_fn("Created SG and connected: {0} -> {1}".format(mat, sg))
    except Exception as exc:
        _warn("Failed to create shading group: {0}".format(exc))
        if log_fn:
            log_fn("CRITICAL ERROR: Failed to create shading group for {0}: {1}".format(mat_name, exc))
        return None

    # Copy textures to library if saving
    if save_folder:
        tex_folder = os.path.join(save_folder, "{0}_maps".format(mat_name))
        _safe_mkdir(tex_folder)
        for attr, path in textures.items():
            if os.path.isfile(path):
                try:
                    fname = os.path.basename(path)
                    dest = os.path.join(tex_folder, fname)
                    shutil.copy2(path, dest)
                    textures[attr] = dest
                except Exception as exc:
                    _warn("Failed to copy texture {0}: {1}".format(path, exc))

    # 2. Connect textures
    connected = set()

    def get_target_attr(attr_key):
        if attr_key in attr_map:
            mapping = attr_map[attr_key]
            if shader_type in mapping:
                return mapping[shader_type]
            if "lambert" in mapping and shader_type == "lambert":
                return mapping["lambert"]
        return None

    def connect_texture(attr, path):
        if not path:
            return

        target_attr = get_target_attr(attr)

        if not target_attr and attr not in ("height", "ao", "orm"):
            if log_fn:
                log_fn("Skipping {0} map (not supported on {1})".format(attr, shader_type))
            return

        if target_attr and not cmds.attributeQuery(target_attr, node=mat, exists=True):
            _warn("Material attribute not found: {0}.{1}".format(mat, target_attr))
            return

        non_color = attr not in ("baseColor", "emission")
        tex = _create_file_texture("{0}_{1}".format(mat_name, attr), path, non_color=non_color)

        def connect_scalar(file_node, dest_attr):
            try:
                cmds.connectAttr("{0}.outColorR".format(file_node), dest_attr, f=True)
                return
            except Exception:
                pass
            try:
                cmds.connectAttr("{0}.outAlpha".format(file_node), dest_attr, f=True)
                return
            except Exception:
                pass
            try:
                cmds.connectAttr("{0}.outColor".format(file_node), dest_attr, f=True)
            except Exception:
                _warn("Failed to connect scalar texture: {0} -> {1}".format(file_node, dest_attr))

        def is_scalar_attr(dest_attr):
            try:
                attr_type = cmds.getAttr(dest_attr, type=True)
                return attr_type in ("double", "float", "doubleLinear", "doubleAngle", "short", "long", "byte")
            except Exception:
                return False

        if attr == "orm":
            if log_fn:
                log_fn("Using ORM map: {0}".format(path))
            rough_attr = get_target_attr("specularRoughness")
            metal_attr = get_target_attr("metalness")
            if rough_attr and "specularRoughness" not in connected:
                cmds.connectAttr("{0}.outColorG".format(tex), "{1}.{2}".format(mat, rough_attr), f=True)
                connected.add("specularRoughness")
                if log_fn:
                    log_fn("Connected ORM G -> specularRoughness")
            if metal_attr and "metalness" not in connected:
                cmds.connectAttr("{0}.outColorB".format(tex), "{0}.{1}".format(mat, metal_attr), f=True)
                connected.add("metalness")
                if log_fn:
                    log_fn("Connected ORM B -> metalness")
            return

        if attr == "normal":
            if arnold_available:
                bump = cmds.shadingNode("aiNormalMap", asUtility=True, name="{0}_NormalMap".format(mat_name))
                cmds.connectAttr("{0}.outColor".format(tex), "{0}.input".format(bump), f=True)
                cmds.connectAttr("{0}.outValue".format(bump), "{0}.{1}".format(mat, target_attr), f=True)
            else:
                bump = cmds.shadingNode("bump2d", asUtility=True, name="{0}_Bump".format(mat_name))
                cmds.setAttr("{0}.bumpInterp".format(bump), 1)
                cmds.connectAttr("{0}.outAlpha".format(tex), "{0}.bumpValue".format(bump), f=True)
                cmds.connectAttr("{0}.outNormal".format(bump), "{0}.{1}".format(mat, target_attr), f=True)
        elif attr == "height":
            if not arnold_available:
                _warn("Height map skipped (Arnold not available).")
                return
            disp = cmds.shadingNode("displacementShader", asShader=True, name="{0}_Displacement".format(mat_name))
            try:
                cmds.connectAttr("{0}.outAlpha".format(tex), "{0}.displacement".format(disp), f=True)
            except Exception:
                cmds.connectAttr("{0}.outColor".format(tex), "{0}.displacement".format(disp), f=True)
            cmds.connectAttr("{0}.displacement".format(disp), "{0}.displacementShader".format(sg), f=True)
        elif attr == "emission":
            if target_attr:
                if shader_type == "aiStandardSurface":
                    cmds.setAttr("{0}.emission".format(mat), 1.0)
                cmds.connectAttr("{0}.outColor".format(tex), "{0}.{1}".format(mat, target_attr), f=True)
                connected.add(attr)
        elif attr == "opacity":
            if target_attr:
                if shader_type in ("blinn", "lambert") and target_attr == "transparency":
                    rev = cmds.shadingNode("reverse", asUtility=True, name="{0}_OpacityInvert".format(mat_name))
                    cmds.connectAttr("{0}.outColor".format(tex), "{0}.input".format(rev), f=True)
                    cmds.connectAttr("{0}.output".format(rev), "{0}.transparency".format(mat), f=True)
                else:
                    cmds.connectAttr("{0}.outColor".format(tex), "{0}.{1}".format(mat, target_attr), f=True)
                connected.add(attr)
        elif attr == "ao":
            pass
        else:
            if target_attr:
                dest_attr = "{0}.{1}".format(mat, target_attr)
                if is_scalar_attr(dest_attr):
                    connect_scalar(tex, dest_attr)
                else:
                    cmds.connectAttr("{0}.outColor".format(tex), dest_attr, f=True)
                connected.add(attr)

    for attr, path in textures.items():
        connect_texture(attr, path)

    # Ensure visible base color in swatch if no baseColor texture was connected.
    if shader_type == "aiStandardSurface":
        base_attr = "{0}.baseColor".format(mat)
        if cmds.attributeQuery("baseColor", node=mat, exists=True):
            try:
                if not cmds.listConnections(base_attr, source=True, destination=False):
                    cmds.setAttr(base_attr, 0.8, 0.8, 0.8, type="double3")
            except Exception:
                pass

    # 3. Create preview plane
    plane = None
    if create_preview:
        plane = _create_preview_plane(mat_name, sg)

    # 4. Setup a simple HDRI environment in viewport
    if create_skydome:
        _create_skydome_light(hdri_path=hdri_path, arnold_available=arnold_available)

    # 5. Best-effort swatch refresh for hypershade
    try:
        swatch_nodes = _collect_shading_nodes(mat, sg)
        _refresh_swatches(swatch_nodes, log_fn=log_fn)
    except Exception:
        pass

    # 6. Save material to project folder
    exported = False
    mat_file = None
    if save_folder:
        _safe_mkdir(save_folder)
        mat_file = os.path.join(save_folder, "{0}.ma".format(mat_name))
        nodes = _collect_shading_nodes(mat, sg)
        if plane:
            nodes.append(plane)
        exported = _export_material_nodes(nodes, mat_file)
        if log_fn:
            log_fn("Exported material: {0} ({1})".format(mat_file, "OK" if exported else "FAILED"))

    return {
        "material": mat,
        "sg": sg,
        "plane": plane,
        "exported": exported,
        "mat_file": mat_file,
    }


def _extract_zip_to_temp(zip_path):
    tmp = tempfile.mkdtemp()
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(tmp)
    return tmp


def _discover_material_folders(root_folder):
    """Return a list of folders (recursive) that likely contain textures."""
    candidates = []
    if not os.path.isdir(root_folder):
        return candidates

    for dirpath, dirnames, filenames in os.walk(root_folder):
        if _list_texture_files(dirpath):
            candidates.append(dirpath)

    seen = set()
    unique = []
    for path in candidates:
        if path not in seen:
            unique.append(path)
            seen.add(path)
    return unique


def batch_import_materials(root_path, save_folder=None, create_preview=True, create_skydome=True, hdri_path=None, render_mode="arnold", log_fn=None):
    """Batch import all subfolders or zip files in root_path."""
    imported = []
    temp_dirs = []

    root_path = _normalize_path(root_path)
    if not os.path.exists(root_path):
        _warn("Source path not found: {0}".format(root_path))
        return imported

    if log_fn:
        log_fn("Batch import source: {0}".format(root_path))

    if zipfile.is_zipfile(root_path):
        tmp = _extract_zip_to_temp(root_path)
        temp_dirs.append(tmp)
        folders = _discover_material_folders(tmp)
        if not folders:
            _warn("No texture folders found in zip: {0}".format(root_path))
        for folder in folders:
            imported.append(import_pbr_material(folder, save_folder=save_folder, create_preview=create_preview,
                                                create_skydome=create_skydome, hdri_path=hdri_path,
                                                render_mode=render_mode, log_fn=log_fn))
        return imported

    if os.path.isdir(root_path):
        folders = _discover_material_folders(root_path)
        for folder in folders:
            imported.append(import_pbr_material(folder, save_folder=save_folder, create_preview=create_preview,
                                                create_skydome=create_skydome, hdri_path=hdri_path,
                                                render_mode=render_mode, log_fn=log_fn))

    for t in temp_dirs:
        try:
            shutil.rmtree(t)
        except Exception:
            pass

    return imported
