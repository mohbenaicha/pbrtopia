"""Legacy wrapper for the Pbrtopia Maya Material Importer package."""

import os
import sys

# Ensure package parent is on sys.path
_PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_PACKAGE_DIR)
if _PARENT_DIR not in sys.path:
    sys.path.insert(0, _PARENT_DIR)

from pbrtopia.ui import show_ui
from pbrtopia.config import PLUGIN_NAME, VERSION

__all__ = ["show_ui", "PLUGIN_NAME", "VERSION"]

if __name__ == "__main__":
    show_ui()
