"""
Arnold helpers for Pbrtopia Maya Material Importer.
"""

import os

import maya.cmds as cmds

from .utils import _warn, _info, _is_unknown_node, _create_file_texture


def _ensure_arnold_loaded(log_fn=None):
    try:
        if not cmds.pluginInfo("mtoa", q=True, loaded=True):
            cmds.loadPlugin("mtoa", quiet=True)

        if log_fn:
            try:
                log_fn("Arnold plugin loaded: {0}".format(cmds.pluginInfo("mtoa", q=True, loaded=True)))
            except Exception:
                pass

        # Force Arnold initialization by setting the renderer.
        try:
            cmds.setAttr("defaultRenderGlobals.currentRenderer", "arnold", type="string")
            if log_fn:
                try:
                    current = cmds.getAttr("defaultRenderGlobals.currentRenderer")
                    log_fn("Current renderer set to: {0}".format(current))
                except Exception:
                    pass
        except Exception as exc:
            if log_fn:
                log_fn("Failed to set renderer to arnold: {0}".format(exc))

        # Definitive test: if we can create the node, Arnold is available.
        test = cmds.createNode("aiStandardSurface")
        cmds.delete(test)
        if log_fn:
            log_fn("Arnold node create test: aiStandardSurface OK")
        return True
    except Exception as exc:
        if log_fn:
            log_fn("Arnold node create test failed: {0}".format(exc))
        _warn("Arnold (mtoa) plugin is not loaded. aiStandardSurface may be unavailable.")
        return False


def _create_skydome_light(hdri_path=None, arnold_available=True):
    if not arnold_available:
        _warn("Arnold not available. Skipping Skydome light.")
        return None
    if cmds.objExists("Pbrtopia_EnvLight"):
        return "Pbrtopia_EnvLight"

    # Maya/Arnold uses aiSkyDomeLight in some versions; try both.
    light = None
    for node_type in ("aiSkyDomeLight", "aiSkydomeLight"):
        try:
            light = cmds.shadingNode(node_type, asLight=True, name="Pbrtopia_EnvLight")
            if light:
                _info("Skydome node create: {0}".format(node_type))
                break
        except Exception:
            light = None
    if not light:
        _warn("Failed to create Skydome light node.")
        return None

    try:
        ntype = cmds.nodeType(light)
        if ntype:
            _info("Skydome node type: {0}".format(ntype))
    except Exception:
        pass

    if _is_unknown_node(light):
        _warn("aiSkydomeLight node is unknown. Skipping Skydome light.")
        try:
            cmds.delete(light)
        except Exception:
            pass
        return None

    if hdri_path and os.path.exists(hdri_path):
        file_node = _create_file_texture("Pbrtopia_HDRI", hdri_path)
        try:
            cmds.connectAttr("{0}.outColor".format(file_node), "{0}.color".format(light), f=True)
        except Exception:
            pass
    return light
