"""
Config for Pbrtopia Maya Material Importer.
"""

PLUGIN_NAME = "Pbrtopia Maya Material Importer"
VERSION = "1.0.0"
WINDOW_NAME = "pbrtopiaMayaImporter"

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".exr", ".tx"}

TEXTURE_KEYWORDS = {
    "baseColor": ["basecolor", "base_color", "albedo", "diffuse", "color", "col"],
    "specularRoughness": ["roughness", "rough"],
    "metalness": ["metallic", "metalness", "metal"],
    "normal": ["normal", "nrm", "nor"],
    "height": ["height", "displacement", "disp"],
    "emission": ["emission", "emissive", "emit"],
    "opacity": ["opacity", "alpha", "transparency"],
    "ao": ["ao", "ambientocclusion", "occlusion"],
    "orm": ["orm", "occlusionroughnessmetallic", "occlusion_roughness_metallic", "arm", "rma"],
}

PROJECT_WEBSITE = "https://pbrtopia.com/"
TERMS_URL = "https://pbrtopia.com/terms"
SUPPORT_URL = "https://pbrtopia.com/contact"

LOGO_FILENAME = "PBRTopiaLogo.png"
