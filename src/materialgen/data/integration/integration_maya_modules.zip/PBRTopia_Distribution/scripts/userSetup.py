"""Initialize PBRTopia UI access on Maya startup."""
import sys
import os
import traceback
import maya.cmds as cmds
import maya.utils

LOG_FILE = os.path.join(os.path.expanduser("~"), "pbrtopia_debug.log")

def simple_log(msg):
    try:
        with open(LOG_FILE, "a") as f:
            f.write(msg + "\n")
    except:
        pass

# Wipe log on start
try:
    with open(LOG_FILE, "w") as f:
        f.write("=== DEBUG SESSION START ===\n")
except:
    pass

simple_log("1. userSetup.py started.")
simple_log("2. Current sys.path:\n" + "\n".join(sys.path))

# --- TEST IMPORT IMMEDIATELY ---
try:
    import pbrtopia
    simple_log("3. SUCCESS: 'import pbrtopia' worked immediately.")
    simple_log("   File: " + str(getattr(pbrtopia, '__file__', 'unknown')))
except ImportError as e:
    simple_log("3. FAIL: Could not import pbrtopia immediately.")
    simple_log("   Error: " + str(e))
except Exception as e:
    simple_log("3. FAIL: General error importing pbrtopia.")
    simple_log("   Error: " + str(e))

def _deferred_startup():
    simple_log("4. Deferred Startup Triggered.")
    try:
        import pbrtopia
        pbrtopia.install_ui_access()
        simple_log("5. UI Install Function called.")
        cmds.warning("PBRTopia Loaded Successfully.")
    except Exception as e:
        simple_log("5. FAIL: Deferred execution failed.")
        simple_log("   " + traceback.format_exc())

maya.utils.executeDeferred(_deferred_startup)
simple_log("6. Deferred function registered.")
